# Punto Pádel — Android (prueba)

Proyecto Android con marcador offline, voces Android TextToSpeech, pantalla encendida, logo e inicio propios.

## Compilar APK sin computadora (GitHub Actions)

1. Crear un repositorio **privado** nuevo en github.com desde Chrome (activar **Sitio de escritorio**).
2. Subir **el contenido descomprimido de esta carpeta** al repositorio, preservando la ruta `.github/workflows/android-apk.yml`. La subida de carpetas completas desde Android puede requerir un gestor de archivos compatible con directorios o un editor Git desde el móvil.
3. Ir a **Actions → Compilar APK Punto Padel → Run workflow**. En la primera subida a `main` también se inicia automáticamente.
4. Esperar el resultado verde, abrir la ejecución y descargar `PuntoPadel-APK-prueba` en **Artifacts**.
5. Extraer el ZIP del artefacto, abrir `app-debug.apk` y permitir instalación desde el navegador/gestor de archivos.

No hay APK precompilada en este ZIP. No es una versión firmada para publicar en Play Store; es una APK debug para pruebas. GitHub puede solicitar activar Actions o verificar la cuenta.

### Limitaciones
El motor TTS utiliza voces del dispositivo, no incluye voces masculinas descargadas. La app mantiene la pantalla encendida mientras está abierta. La alarma en segundo plano con el teléfono bloqueado requiere implementación nativa adicional.
