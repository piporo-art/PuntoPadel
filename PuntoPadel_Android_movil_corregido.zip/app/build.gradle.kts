plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.puntopadel.app"
    compileSdk = 35
    defaultConfig { applicationId = "com.puntopadel.app"; minSdk = 26; targetSdk = 35; versionCode = 27; versionName = "1.0-beta" }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
