package com.puntopadel.app

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private var pending: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tts = TextToSpeech(this, this)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(VoiceBridge(), "AndroidTTS")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val engine = tts ?: return
        val argentina = engine.setLanguage(Locale("es", "AR"))
        if (argentina == TextToSpeech.LANG_MISSING_DATA || argentina == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.language = Locale("es", "ES")
        }
        engine.setSpeechRate(0.94f)
        ttsReady = true
        pending?.let { message -> pending = null; speakNative(message) }
    }

    private fun speakNative(text: String) {
        runOnUiThread {
            if (!ttsReady) { pending = text; return@runOnUiThread }
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "padel-${System.nanoTime()}")
        }
    }

    inner class VoiceBridge {
        @JavascriptInterface fun speak(text: String) { speakNative(text.take(1500)) }
    }

    @Deprecated("Android back navigation")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        ttsReady = false
        web.removeJavascriptInterface("AndroidTTS")
        web.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
