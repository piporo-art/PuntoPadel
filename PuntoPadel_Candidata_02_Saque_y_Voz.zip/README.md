# Punto Pádel — Candidata 02 (saque y comandos de voz)

Cambios respecto de Candidata Final 01:
- El cronómetro de PARTIDO queda en 00:00:00 hasta pulsar **Elegir saque** (azul o rojo).
- Al elegir saque, ambos botones desaparecen; saca Jugador 1 de ese equipo desde DERECHA.
- Los botones + Punto están deshabilitados antes de elegir saque.
- Botón «Activar comandos de voz»: reconocimiento nativo Android en español. Se solicita permiso de micrófono. Frase exacta «Punto para + nombre de jugador»; requiere nombres distinguibles. Los botones táctiles funcionan siempre.
- Durante síntesis de voz, se detiene temporalmente el reconocimiento para minimizar realimentación.
- El reconocimiento puede requerir el servicio de Google/Android y paquetes de idioma; funcionamiento sin red depende del motor disponible. No se garantiza escucha ininterrumpida por restricciones del sistema.

**Pruebas pendientes en Android real:** permiso micrófono, reconocimiento, anuncios/pausas, cambio de orientación, inicio del cronómetro y ciclos completos de sets/torneos. Proyecto empaquetado para compilar mediante GitHub Actions; no se ha compilado APK localmente.

**Instalación:** APK debug de GitHub puede cambiar firma entre ejecuciones. Para actualizaciones sin desinstalar, configurar keystore fijo de firma.
