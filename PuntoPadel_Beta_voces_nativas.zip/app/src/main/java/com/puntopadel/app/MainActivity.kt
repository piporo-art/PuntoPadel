package com.puntopadel.app

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import android.speech.tts.Voice

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private var pending: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tts = TextToSpeech(this, this)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(VoiceBridge(), "AndroidTTS")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val engine = tts ?: return
        val argentina = engine.setLanguage(Locale("es", "AR"))
        if (argentina == TextToSpeech.LANG_MISSING_DATA || argentina == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.language = Locale("es", "ES")
        }
        engine.setSpeechRate(0.94f)
        ttsReady = true
        pending?.let { message -> pending = null; speakNative(message) }
    }

    private fun speakNative(text: String) {
        runOnUiThread {
            if (!ttsReady) { pending = text; return@runOnUiThread }
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "padel-${System.nanoTime()}")
        }
    }

    private fun nativeVoices(): String {
        val arr = JSONArray()
        tts?.voices?.sortedWith(compareBy({ it.locale.language }, { it.name }))?.forEach { voice ->
            val language = voice.locale.language
            if (language in setOf("es", "en", "it", "fr", "de")) {
                arr.put(JSONObject().put("id", voice.name).put("name", voice.name)
                    .put("lang", voice.locale.toLanguageTag())
                    .put("network", voice.isNetworkConnectionRequired))
            }
        }
        return arr.toString()
    }

    private fun configureVoice(lang: String, gender: String, voiceId: String): String {
        val engine = tts ?: return "Motor de voz no disponible"
        if (!ttsReady) return "Motor de voz inicializando"
        val desired = engine.voices.orEmpty().filter { it.locale.language == lang }
        if (desired.isEmpty()) return "No hay voces instaladas para este idioma"
        val named = desired.firstOrNull { it.name == voiceId }
        // Android TTS does not expose gender in its Voice API. Only infer gender when
        // the voice's actual name is explicitly tagged; never fake a male voice by pitch.
        val genderPattern = if (gender == "male") Regex("male|masculin|hombre|\\bm\\b", RegexOption.IGNORE_CASE)
                            else Regex("female|femenin|mujer|\\bf\\b", RegexOption.IGNORE_CASE)
        val selected = named ?: if (gender != "auto") desired.firstOrNull { genderPattern.containsMatchIn(it.name) } else null
        if (gender == "male" && selected == null) return "No se encontró voz masculina identificada. Elegí una voz por nombre en la lista."
        val chosen = selected ?: desired.firstOrNull { it.locale.country == "AR" } ?: desired.first()
        val code = engine.setVoice(chosen)
        if (code != TextToSpeech.SUCCESS) return "No se pudo activar la voz elegida"
        engine.setPitch(1.0f)
        engine.setSpeechRate(0.94f)
        return "Voz seleccionada: ${chosen.name}"
    }

    inner class VoiceBridge {
        @JavascriptInterface fun speak(text: String) { speakNative(text.take(1500)) }
        @JavascriptInterface fun getVoices(): String = nativeVoices()
        @JavascriptInterface fun setVoicePreference(lang: String, gender: String, voiceId: String): String {
            var result = "Motor de voz inicializando"
            // JS interface calls run on WebView bridge background thread; TTS accepts calls here.
            result = configureVoice(lang, gender, voiceId)
            return result
        }
    }

    @Deprecated("Android back navigation")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        ttsReady = false
        web.removeJavascriptInterface("AndroidTTS")
        web.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
