# Punto Pádel — Candidata 02 (saque y comandos de voz)

Cambios respecto de Candidata Final 01:
- El cronómetro de PARTIDO queda en 00:00:00 hasta pulsar **Elegir saque** (azul o rojo).
- Al elegir saque, ambos botones desaparecen; saca Jugador 1 de ese equipo desde DERECHA.
- Los botones + Punto están deshabilitados antes de elegir saque.
- Botón «Activar comandos de voz»: reconocimiento nativo Android en español. Se solicita permiso de micrófono. Frase exacta «Punto para + nombre de jugador»; requiere nombres distinguibles. Los botones táctiles funcionan siempre.
- Durante síntesis de voz, se detiene temporalmente el reconocimiento para minimizar realimentación.
- El reconocimiento puede requerir el servicio de Google/Android y paquetes de idioma; funcionamiento sin red depende del motor disponible. No se garantiza escucha ininterrumpida por restricciones del sistema.

**Pruebas pendientes en Android real:** permiso micrófono, reconocimiento, anuncios/pausas, cambio de orientación, inicio del cronómetro y ciclos completos de sets/torneos. Proyecto empaquetado para compilar mediante GitHub Actions; no se ha compilado APK localmente.

**Instalación:** APK debug de GitHub puede cambiar firma entre ejecuciones. Para actualizaciones sin desinstalar, configurar keystore fijo de firma.

## Corrección Candidata 03
- Corrige dictado «Dany»/«Dani» y variaciones de escritura de nombres con y/i.
- Analiza hasta tres alternativas del motor de voz, en vez de depender exclusivamente de la primera.
- Requiere «Punto para + nombre», evita marcar cuando los nombres se solapan o resultan ambiguos.
- Pendiente de verificar mediante instalación Android real.


## Candidata 04 — controles rápidos
- Comandos de voz y audio en interruptores independientes.
- Botones táctiles + PUNTO disponibles cuando se escucha voz.
- Puntuación avanzada desplegable, botón de finalización rojo con confirmación ya existente.
- Se conserva el reconocimiento y los datos de la candidata 03.
- Probar en Android; reconocimiento a 2 metros no está garantizado por software.

## Candidata 05 — encabezado limpio
- Eliminado indicador visual «SIN INTERNET» del encabezado.
- Sin cambios en la lógica de puntuación, voz, reloj ni torneos.
