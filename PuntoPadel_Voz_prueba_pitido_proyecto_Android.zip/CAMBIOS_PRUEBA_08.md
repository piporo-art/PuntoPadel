# Punto Pádel Android: actualización de fuente para prueba de voz

- Incluye el HTML Prueba 08 con diagnóstico visible y comandos Punto Vero, Punto Dani y Deshacer.
- Conserva las funciones del marcador incluidas en ese HTML.
- Emplea el puente AndroidVoice y el SpeechRecognizer nativo, no Web Speech del navegador.
- Muestra errores nativos con descripción y transcripción parcial en la pantalla.
- Para generar una APK hace falta compilar con Android SDK/Gradle o el workflow GitHub Actions incluido.
- No se ha compilado ni probado en un teléfono. No se garantiza que todos los permisos y modelos de voz estén disponibles.
