plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.puntopadel.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.puntopadel.stable"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
    signingConfigs {
        create("permanent") {
            // Keystore se entrega por GitHub Actions Secrets, NUNCA dentro del ZIP.
            val path = System.getenv("PUNTO_KEYSTORE_PATH")
            val storePass = System.getenv("PUNTO_STORE_PASSWORD")
            val alias = System.getenv("PUNTO_KEY_ALIAS")
            val keyPass = System.getenv("PUNTO_KEY_PASSWORD")
            if (!path.isNullOrBlank() && !storePass.isNullOrBlank() && !alias.isNullOrBlank() && !keyPass.isNullOrBlank()) {
                storeFile = file(path)
                storePassword = storePass
                keyAlias = alias
                keyPassword = keyPass
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("permanent")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
