package com.puntopadel.app

import android.app.Activity
import android.os.Bundle
import android.net.Uri
import java.io.OutputStreamWriter
import android.view.WindowManager
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import android.speech.tts.Voice
import android.speech.tts.UtteranceProgressListener
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper


class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private var pendingJsonExport: String? = null
    private val exportRequestCode = 7312
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private var pending: String? = null
    private var recognizer: SpeechRecognizer? = null
    private var listeningDesired = false
    private var talking = false
    private var activeListening = false
    private val handler = Handler(Looper.getMainLooper())
    private val restart = Runnable { startVoiceRecognition() }
    private fun sendVoiceStatus(text: String) { web.evaluateJavascript("window.PuntoPadelVoice?.onStatus(${JSONObject.quote(text)})", null) }
    private fun startVoiceRecognition() {
        if(!listeningDesired || talking || activeListening || isFinishing) return
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 481); return
        }
        if(!SpeechRecognizer.isRecognitionAvailable(this)) { sendVoiceStatus("Reconocimiento de voz no disponible en Android"); return }
        if(recognizer==null) {
            recognizer=SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object: RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { sendVoiceStatus("🎙️ Escuchando: Punto para + nombre") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) { activeListening=false; retryListen() }
                override fun onResults(results: Bundle?) {
                    activeListening=false
                    val phrases=results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    phrases?.take(3)?.let { candidates ->
                        val payload=org.json.JSONArray(candidates).toString()
                        web.evaluateJavascript("window.PuntoPadelVoice?.onResult($payload)",null)
                    }
                    retryListen()
                }
            })
        }
        val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"es-AR")
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false)
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3)
        activeListening=true
        try { recognizer?.startListening(intent) } catch(e:Exception) { activeListening=false; sendVoiceStatus("Error de micrófono: ${e.message}");retryListen() }
    }
    private fun retryListen(){handler.removeCallbacks(restart);if(listeningDesired && !talking)handler.postDelayed(restart,800)}
    private fun pauseVoiceRecognition(){handler.removeCallbacks(restart);activeListening=false;recognizer?.cancel()}
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==481){if(grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED) startVoiceRecognition() else sendVoiceStatus("Necesitás permitir el micrófono para comandos de voz")}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tts = TextToSpeech(this, this)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(VoiceBridge(), "AndroidTTS")
        web.addJavascriptInterface(CommandBridge(), "AndroidVoice")
        web.addJavascriptInterface(ExportBridge(), "AndroidExport")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val engine = tts ?: return
        val argentina = engine.setLanguage(Locale("es", "AR"))
        if (argentina == TextToSpeech.LANG_MISSING_DATA || argentina == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.language = Locale("es", "ES")
        }
        engine.setOnUtteranceProgressListener(object: UtteranceProgressListener(){
            override fun onStart(utteranceId:String?){runOnUiThread { talking=true;pauseVoiceRecognition() }}
            override fun onDone(utteranceId:String?){runOnUiThread { talking=false;retryListen() }}
            @Deprecated("legacy") override fun onError(utteranceId:String?){runOnUiThread { talking=false;retryListen() }}
        })
        engine.setSpeechRate(0.94f)
        ttsReady = true
        pending?.let { message -> pending = null; speakNative(message) }
    }

    private fun speakNative(text: String) {
        runOnUiThread {
            if (!ttsReady) { pending = text; return@runOnUiThread }
            talking=true
            pauseVoiceRecognition()
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "padel-${System.nanoTime()}")
        }
    }

    private fun nativeVoices(): String {
        val arr = JSONArray()
        tts?.voices?.sortedWith(compareBy({ it.locale.language }, { it.name }))?.forEach { voice ->
            val language = voice.locale.language
            if (language in setOf("es", "en", "it", "fr", "de")) {
                arr.put(JSONObject().put("id", voice.name).put("name", voice.name)
                    .put("lang", voice.locale.toLanguageTag())
                    .put("network", voice.isNetworkConnectionRequired))
            }
        }
        return arr.toString()
    }

    private fun configureVoice(lang: String, gender: String, voiceId: String): String {
        val engine = tts ?: return "Motor de voz no disponible"
        if (!ttsReady) return "Motor de voz inicializando"
        val desired = engine.voices.orEmpty().filter { it.locale.language == lang }
        if (desired.isEmpty()) return "No hay voces instaladas para este idioma"
        val named = desired.firstOrNull { it.name == voiceId && !it.isNetworkConnectionRequired }
        val maleLocal = desired.firstOrNull { it.name == "es-us-x-esd-local" && !it.isNetworkConnectionRequired }
        val femaleLocal = desired.firstOrNull { it.name == "es-es-x-eea-local" && !it.isNetworkConnectionRequired }
        val femalePreferred = desired.firstOrNull { it.name == "es-es-x-eea-network" }
        val offlineDesired = desired.filter { !it.isNetworkConnectionRequired }
        // Android TTS does not expose gender in its Voice API. Only infer gender when
        // the voice's actual name is explicitly tagged; never fake a male voice by pitch.
        val genderPattern = if (gender == "male") Regex("male|masculin|hombre|\\bm\\b", RegexOption.IGNORE_CASE)
                            else Regex("female|femenin|mujer|\\bf\\b", RegexOption.IGNORE_CASE)
        val selected = named ?: when(gender){
            "male" -> maleLocal ?: offlineDesired.firstOrNull { genderPattern.containsMatchIn(it.name) }
            "female" -> femaleLocal ?: offlineDesired.firstOrNull { genderPattern.containsMatchIn(it.name) } ?: femalePreferred
            else -> null
        }
        if (gender == "male" && selected == null) return "No se encontró voz masculina instalada. Elegí una voz por nombre en la lista."
        val chosen = selected ?: offlineDesired.firstOrNull { it.locale.country == "AR" } ?: offlineDesired.firstOrNull() ?: desired.first()
        val code = engine.setVoice(chosen)
        if (code != TextToSpeech.SUCCESS) return "No se pudo activar la voz elegida"
        engine.setPitch(1.0f)
        engine.setSpeechRate(0.94f)
        return "Voz seleccionada: ${chosen.name}"
    }

    private fun startJsonExport(json: String) {
        runOnUiThread {
            try {
                pendingJsonExport = json
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "punto-padel-historial.json")
                }
                startActivityForResult(intent, exportRequestCode)
            } catch (e: Exception) {
                pendingJsonExport = null
                web.evaluateJavascript("window.alert('No se pudo abrir Guardar archivo')", null)
            }
        }
    }

    @Deprecated("Android document picker result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != exportRequestCode) return
        val json = pendingJsonExport ?: return
        pendingJsonExport = null
        val uri: Uri = data?.data ?: return
        if (resultCode != Activity.RESULT_OK) return
        try {
            contentResolver.openOutputStream(uri)?.use { stream ->
                OutputStreamWriter(stream, Charsets.UTF_8).use { it.write(json) }
            } ?: throw IllegalStateException("No se pudo abrir el archivo")
            web.evaluateJavascript("window.PuntoPadelExport?.onSaved(true)", null)
        } catch (e: Exception) {
            web.evaluateJavascript("window.PuntoPadelExport?.onSaved(false)", null)
        }
    }

    inner class ExportBridge {
        @JavascriptInterface fun saveJson(json: String) {
            if (json.length > 4_000_000) return
            startJsonExport(json)
        }
    }

    inner class VoiceBridge {
        @JavascriptInterface fun speak(text: String) { speakNative(text.take(1500)) }
        @JavascriptInterface fun getVoices(): String = nativeVoices()
        @JavascriptInterface fun setVoicePreference(lang: String, gender: String, voiceId: String): String {
            var result = "Motor de voz inicializando"
            // JS interface calls run on WebView bridge background thread; TTS accepts calls here.
            result = configureVoice(lang, gender, voiceId)
            return result
        }
    }

    inner class CommandBridge {
        @JavascriptInterface fun setListening(enabled:Boolean){runOnUiThread {
            listeningDesired=enabled
            if(enabled)startVoiceRecognition() else {pauseVoiceRecognition();sendVoiceStatus("🎙️ Micrófono desactivado")}
        }}
    }

    @Deprecated("Android back navigation")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        ttsReady = false
        listeningDesired=false
        handler.removeCallbacks(restart)
        recognizer?.destroy()
        web.removeJavascriptInterface("AndroidVoice")
        web.removeJavascriptInterface("AndroidTTS")
        web.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
