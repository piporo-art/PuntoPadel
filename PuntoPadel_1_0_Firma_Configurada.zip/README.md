# Punto Pádel 1.0 — proyecto preparado para firma permanente

Base funcional: **PuntoPadel_1_0_Respaldo_Android.zip**, cuya exportación JSON fue probada en Android. No se alteró la interfaz ni el motor de juego.

Este proyecto **NO incluye clave privada de firma**. Para una APK actualizable, conservar permanentemente el archivo .jks y sus contraseñas, preferentemente en gestor de contraseñas / copia cifrada.

Secretos requeridos en GitHub Actions:
- `PUNTO_KEYSTORE_BASE64`: contenido base64 del archivo .jks.
- `PUNTO_STORE_PASSWORD`: contraseña del almacén.
- `PUNTO_KEY_ALIAS`: alias de la clave.
- `PUNTO_KEY_PASSWORD`: contraseña de la clave.

Compilar `:app:assembleRelease`, NO `assembleDebug`. La APK final se llama `app-release.apk`. Nunca subir el .jks al repositorio público ni pegar sus contraseñas en chats públicos.

**Nota de integración:** si utilizás un workflow externo en la raíz del repositorio que descomprime el ZIP, ese workflow debe exportar las 4 variables de firma antes del comando Gradle y cambiar su compilación a `:app:assembleRelease`. El workflow que está DENTRO de este ZIP no reemplaza automáticamente el workflow externo.

La firma nueva exige instalar esta 1.0 como aplicación nueva o desinstalar la vieja con el mismo applicationId. Se aceptó comenzar de cero. No desinstalar hasta comprobar el build final.
