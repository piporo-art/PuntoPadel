Punto Pádel 1.0 — Candidata de respaldo Android

Base: Visual Premium 01, misma interfaz y lógica.
Cambios: exportar historial mediante selector de documentos Android (ACTION_CREATE_DOCUMENT), corrección de current en JSON, nuevo applicationId com.puntopadel.stable para que conviva con Beta.

La APK de este ZIP se compila con firma debug TEMPORAL: todavía NO está configurada la firma permanente. Esto significa que no es una versión final instalable como actualización entre compilaciones.
NO BORRES la app Beta instalada; primero verificar exportación y funcionamiento en candidata 1.0.
Para lanzar 1.0 permanente se requiere una clave de firma segura guardada en GitHub Actions Secrets, nunca en el ZIP público.
